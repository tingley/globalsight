#!/usr/bin/env ruby

if RUBY_VERSION < "1.9"
  require 'rubygems/open-uri'
else
  require 'open-uri'
end
