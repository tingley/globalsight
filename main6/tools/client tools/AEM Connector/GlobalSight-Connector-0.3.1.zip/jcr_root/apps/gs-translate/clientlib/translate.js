CQ.Ext.ns("MyClientLib");

MyClientLib.ContentFinder = {

    addGsTranslate: function(sk, result, ipAddress){
        var pagePanel = sk.panels["PAGE"];

        var flag = true;
        if (result ==1) {
            flag = false;
        }

        var button = pagePanel.findBy(function(comp){
            return comp["name"] == "GLOBALSIGHT_TRANSLATE";
        }, pagePanel);


        if(button && button.length > 0){
            return;
        }

        button = {
            xtype: "button",
            scope: sk,
            name: "GLOBALSIGHT_TRANSLATE",
            text: "Translate By GlobalSight",
            "context": [
                CQ.wcm.Sidekick.PAGE
            ],
            handler: function(){
                var serverIp = ipAddress;
                 window.open('http://' + serverIp + ':4502/content/globalsight/createJob.html', 'createjob', 'fullscreen=yes, menubar=no, toolbar=no, scrollbars=yes, resizable=yes, resizable=1'); 
            },

            disabled:(flag)
        };

        pagePanel.insert(11,button);
        sk.actns.push(button);
    },

    addToCart: function(sk){
		var pagePanel = sk.panels["PAGE"];
 
        var button = pagePanel.findBy(function(comp){
            return comp["name"] == "ADD2_CART";
        }, pagePanel);

        if(button && button.length > 0){
            return;
        }

        button = {
            xtype: "button",
            scope: sk,
            name: "ADD2_CART",
            text: "Add to cart",
            "context": [
                CQ.wcm.Sidekick.PAGE
            ],
            handler: function(){
                //store to cart
                var pagePath = CQ.WCM.getPagePath();
                var params = {"nodePath": pagePath};

				CQ.shared.HTTP.post("/bin/mySearchServlet", function(options, success, response) {
                                        if (!success) {
                                            CQ.Ext.Msg.alert(
                                                CQ.I18n.getMessage("Error"),
                                                CQ.I18n.getMessage("Could not add current page to cart."));
                                        } else {
                                            CQ.Ext.Msg.alert("Success","Current page has been added to the cart.");
                                        }
                                    },params);
            }
        };

        pagePanel.insert(10,button);
        sk.actns.push(button);
	}
};
 
(function(){

    var result;
    var ipAddress;

    CQ.Ext.Ajax.request({
        url: CQ.HTTP.externalize("/bin/customer"),
        method: "GET",
        success: function(response) {
           	var info = CQ.Ext.util.JSON.decode(response.responseText);
            var ack = info[0].result;
            var ip = info[1].ipAddress;
			result = ack;
            ipAddress = ip;
        },
        failure: function(response) {
        }
	});


    var c = MyClientLib.ContentFinder;

    if( ( window.location.pathname == "/cf" ) || ( window.location.pathname.indexOf("/content") == 0)){
        var SK_INTERVAL = setInterval(function(){
        var sk = CQ.WCM.getSidekick();

        if(sk){
                clearInterval(SK_INTERVAL);

                c.addGsTranslate(sk, result, ipAddress);

                //Add to cart
				c.addToCart(sk);

         }
       }, 250);
    }
})();