1. Copy all the files to linux, and make sure enough permission
2. Edit GSSmartBox.conf file to do the configuration
3. In terminal, under GSSmartBox directory, run the command "./GSSmartBox start"