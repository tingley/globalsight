1. Copy all the files to windows
2. Edit GSSmartBox.cfg.xml file to do the configuration
3. Double click GSSmartBox.bat to run the application or double click InstallGSSmartBox-NT.bat to install as service, then start this service