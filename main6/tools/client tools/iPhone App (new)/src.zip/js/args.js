var webSight;
var MobileService = "globalsight/MobileService?";
var me;
var alertMessage;
var accessToken;
var ajaxBackData;
var myMenus;
var permissions;
var message;
var loadJob;
var loadActivity;
var alertContent;
var alertWindow;
var pageNum = 5;
var activitylist;
var joblist;
var detailJobId;
var detailActivityId;
var jobScroll, jobPullDownEl, jobPullDownOffset, jobPullUpEl, jobPullUpOffset;
var activityScroll, activityPullDownEl, activityPullDownOffset, activityPullUpEl, activitypullUpOffset;

var jobPage = {
	state : "",
	detailJob : ""
};

var activityPage = {
	state : "",
	detailActivity : ""
};

var listActivityUI = [ "jobId", "taskId", "jobName", "taskWC", "locales",
                  		"assignees", "acceptor", "activity" ];