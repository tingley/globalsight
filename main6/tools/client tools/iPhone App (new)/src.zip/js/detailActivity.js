$("#detailActivity").live("pageinit", function(event) {
	initDetailActivityUI();
	initDetailActivityEvent();
	initDetailActivityFooter();
});

$("#detailActivity").live("pageshow", function(event) {
	alertContent = $("#messageContent5");
	alertWindow = $("#dialog5");
});

function initDetailActivityUI() {
	var data = activityPage.detailActivity;

	if (!data) {
		return;
	}
	
	$.each(listActivityUI, function(key, name) {
		activityPage.detailActivity.name = detailActivityLi.find("." + name).text();
		$("#detailActivity").find("." + name).text(data[name]);
	});

	var orginTr = $("tr[name='FilesTr']").eq(0);
	for ( var i = 0; i < data.Files.length; i++) {
		var file = data.Files[i];
		var node = orginTr.clone(true);
		var fileTable = $("table[name='FilesTable']").eq(0);
		fileTable.append(node);
		node.find(".fileName").text(file.fileName);
		node.find(".taskFileWC").text(file.taskFileWC);
	}

	orginTr.remove();
	
	if (hasPermission("projects_manage")) {
		$("#detailActivity").find(".assigneesLab").show();
	}
}

function initDetailActivityEvent() {
	$("#detailActivity").find(".buttomTools[name='logout']").bind("click", logout);
	$("#detailActivity").find("#Accept").bind("click", acceptDetailActivity);
	$("#detailActivity").find("#Complete").bind("click", completeDetailActivity);
}

function acceptDetailActivity() {

	if (!hasPermission("perm_activities_accept")) {
		showMessage(noPermissionAcceptTask);
		return;
	}

	var notInAccepts = false;

	if (hasPermission("projects_manage")) {
		var ascer=activityPage.detailActivity.assignees;
		if($.inArray(me, ascer)<0){
			notInAccepts = true;
		}
	}
	
	if (notInAccepts) {
		showMessage(acceptDetailActivityAssigness);
		return;
	}

	var confirmCallBack = function(button) {
		$("#confirmDialog5").popup("close");

		var ajaxData = {};
		ajaxData["taskId"] = activityPage.detailActivity.taskId;
		ajaxData["action"] = "acceptTask";

		var callbackfunc = function() {
			$("#detailActivity").find("#Accept").hide();
			$("#detailActivity").find("#Complete").show();
			detailActivityId = activityPage.detailActivity.taskId;
		};

		useAjax(ajaxData, callbackfunc);

	};
	confirm5(confirmAcceptActivityHead, confirmAcceptActivityContent, confirmCallBack);

}

function completeDetailActivity() {

	var notInAccepts = false;

	if (hasPermission("projects_manage")) {
		var ascer=activityPage.detailActivity.assignees;
		if($.inArray(me, ascer)<0){
			notInAccepts = true;
		}
	}
	
	if (notInAccepts) {
		showMessage(completeDetailActivityAssigness);
		return;
	}

	var confirmCallBack = function(button) {
		$("#confirmDialog5").popup("close");

		var ajaxData = {};
		ajaxData["taskId"] = activityPage.detailActivity.taskId;
		ajaxData["action"] = "completeTask";

		var callbackfunc = function() {
			$("#detailActivity").find("#Accept").hide();
			$("#detailActivity").find("#Complete").hide();
			detailActivityId = activityPage.detailActivity.taskId;
		};

		useAjax(ajaxData, callbackfunc);

	};
	confirm5(confirmAcceptActivityHead, confirmAcceptActivityContent, confirmCallBack);

}

function confirm5(head, msg, func) {
	$("#confirmHeader5").text(head);
	$("#confirmMessage5").text(msg);

	$("#okButton5").die();
	$("#okButton5").live("click", func);
	$("#confirmDialog5").popup("open");
}


function initDetailActivityFooter() {
	if (activityPage.state == "available") {
		$("#detailActivity").find("#Accept").show();
		$("#detailActivity").find("#Complete").hide();
	} else if (activityPage.state == "accepted") {
		$("#detailActivity").find("#Accept").hide();
		$("#detailActivity").find("#Complete").show();
	}else if (activityPage.state == "finished") {
		$("#detailActivity").find("#Accept").hide();
		$("#detailActivity").find("#Complete").hide();
	}
};

function confirm3(head, msg, func) {
	$("#confirmHeader3").text(head);
	$("#confirmMessage3").text(msg);

	$("#okButton3").die();
	$("#okButton3").live("click", func);
	$("#confirmDialog3").popup("open");
}