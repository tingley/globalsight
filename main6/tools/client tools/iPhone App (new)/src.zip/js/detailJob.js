$("#detailJob").live("pageinit", function(event) {
	initDetailJobUI();
	initDetailJobImg();
	initDetailJobEvent();
	initDetailJobFooter();
});

$("#detailJob").live("pageshow", function(event) {
	alertContent = $("#messageContent3");
	alertWindow = $("#dialog3");
});

function initDetailJobUI() {
	var data = jobPage.detailJob;

	if (!data) {
		return;
	}

	$("#detailJob").find(".jobId").text(data.jobId);
	$("#detailJob").find(".jobName").text(data.jobName);
	$("#detailJob").find(".dateCreated").text(data.dateCreated);
	$("#detailJob").find(".jobWC").text(data.jobWC);

	var orginTr = $("tr[name='SourceFilesTr']").eq(0);
	for ( var i = 0; i < data.SourceFiles.length; i++) {
		var sourcefile = data.SourceFiles[i];
		var node = orginTr.clone(true);
		var fileTable = $("table[name='SourceFilesTable']").eq(0);
		fileTable.append(node);
		node.find(".fileName").text(sourcefile.fileName);
		node.find(".fileProfile").text(sourcefile.fileProfile);
		node.find(".jobFileWC").text(sourcefile.jobFileWC);
	}

	orginTr = $("tr[name='WorkflowsTr']").eq(0);
	for ( var i = 0; i < data.Workflows.length; i++) {
		var workflow = data.Workflows[i];
		var node = orginTr.clone(true);
		var fileTable = $("table[name='WorkflowsTable']").eq(0);
		fileTable.append(node);
		node.find(".wfId").text(workflow.wfId);
		node.find(".targetLocale").text(workflow.targetLocale);
		node.find(".state").text(workflow.state);
		node.find(".CurrentAc").text(workflow.CurrentAc);
	}

	orginTr.remove();
}

function initDetailJobEvent() {
	$("#detailJob").find(".buttomTools[name='logout']").bind("click", logout);
	$("#detailJob").find("#Discard").bind("click", discardWorkflow);
	$("#detailJob").find("#Dispatch").bind("click", dispatchWorkflow);
}

function initDetailJobImg() {
	var ceckImg = $(".imgContainer");

	ceckImg.each(function() {
		$(this).bind("click", toggleV);
	});
}

function initDetailJobFooter() {
	if (jobPage.state == "ready") {
		$("#detailJob").find("#Discard").show();
		$("#detailJob").find("#Dispatch").show();
	} else if (jobPage.state == "dispatched") {
		$("#detailJob").find("#Discard").show();
		$("#detailJob").find("#Dispatch").hide();
	}else if (jobPage.state == "exported") {
		$("#detailJob").find("#Discard").hide();
		$("#detailJob").find("#Dispatch").hide();
	}else if (jobPage.state == "pending") {
		$("#detailJob").find("#Discard").show();
		$("#detailJob").find("#Dispatch").hide();
	}
}

function dispatchWorkflow() {

	if (!hasPermission("perm_job_workflows_dispatch")) {
		showMessage(noPermissionDispatchWorkflow);
		return;
	}

	var ch = $("tr[name='WorkflowsTr']");
	var temp = [];
	var error;
	ch.each(function() {
		var bl = $(this).find(".selected").is(":visible");
		var state=$(this).find(".state").text();
		
		if (bl) {
			if (state != "Ready"){
				error = dispatchWorkflowStateWrong;
				return;
			}
			
			var value = $(this).find(".wfId").text();
			temp.push(value);
		}
	});
	
	if (error) {
		showMessage(error);
		return;
	}


	if (temp.length == 0) {
		showMessage(noWorkflowSelected);
		return;
	}

	var confirmCallBack = function(button) {
		$("#confirmDialog3").popup("close");

		var ajaxData = {};
		ajaxData["wfId"] = temp;
		ajaxData["action"] = "dispatchWorkflow";

		var callbackfunc = function() {
			var ch = $("tr[name='WorkflowsTr']");
			ch.each(updateWorkflowToDispatch);
			detailJobId = $("#detailJob").find(".jobId").text();
		};

		useAjax(ajaxData, callbackfunc);

	};
	confirm3(confirmDispatchWorkflowHead, confirmDispatchWorkflowContent, confirmCallBack);
}

function discardWorkflow() {

	if (!hasPermission("perm_job_workflows_discard")) {
		showMessage(noPermissionDiscardWorkflow);
		return;
	}

	var ch = $("tr[name='WorkflowsTr']");
	var temp = [];
	var error;
	ch.each(function() {
		var bl = $(this).find(".selected").is(":visible");
		var state=$(this).find(".state").text();
		
		if (bl) {
			if (state != "Ready" && state != "Dispatched"){
				error = discardWorkflowStateWrong;
				return;
			}
			
			var value = $(this).find(".wfId").text();
			temp.push(value);
		}
	});
	
	if (error) {
		showMessage(error);
		return;
	}


	if (temp.length == 0) {
		showMessage(noWorkflowSelected);
		return;
	}

	var confirmCallBack = function(button) {
		$("#confirmDialog3").popup("close");

		var ajaxData = {};
		ajaxData["wfId"] = temp;
		ajaxData["action"] = "discardWorkflow";

		var callbackfunc = function() {
			var ch = $("tr[name='WorkflowsTr']");
			ch.each(hideSelectWorkflow);
			detailJobId = $("#detailJob").find(".jobId").text();
		};

		useAjax(ajaxData, callbackfunc);

	};
	confirm3(confirmDispatchWorkflowHead, confirmDispatchWorkflowContent, confirmCallBack);
}

function updateWorkflowToDispatch() {
	var bl = $(this).find(".selected").is(":visible");	
	if (bl) {
		var stateDiv = $(this).find(".state");
		stateDiv.text("Dispatched");
		stateDiv[0].style.color = "#D56F2B";
		
		var wfId = $(this).find(".wfId").text();
		for (var i = 0; i < ajaxBackData.length; i++) {
			if (wfId == ajaxBackData[i].wfId) {
				var acDiv = $(this).find(".CurrentAc");
				acDiv.text(ajaxBackData[i].CurrentAc);
				acDiv[0].style.color = "#D56F2B";
			}
		}
	}
}

function hideSelectWorkflow() {
	var bl = $(this).find(".selected").is(":visible");
	if (bl) {
		$(this).hide('normal', function() {
			$(this).remove();
		});
	}
}

function confirm3(head, msg, func) {
	$("#confirmHeader3").text(head);
	$("#confirmMessage3").text(msg);

	$("#okButton3").die();
	$("#okButton3").live("click", func);
	$("#confirmDialog3").popup("open");
}