var loginIds = [ "ipname", "port", "userName", "password", "toggleswitch1", "autoLogin" ];

function initInput() {
	$("input").each(function() {
		var id = $(this).attr("id");
		var cc = $.cookie(id);
		if (cc) {
			$(this).val(cc);
		}
	});
	
	if ($.cookie("toggleswitch1") == "on") {
		$("#toggleswitch1")[0].selectedIndex = 1;
		$('#toggleswitch1').slider('refresh');

		loginUser();
	}
	
	if ($.cookie("autoLogin") == "on") {
		$("#autoLogin")[0].selectedIndex = 1;
		$('#autoLogin').slider('refresh');

		loginUser();
	}
}

$("#login").live("pageshow", function(event) {
	alertContent = $("#messageContent");
	alertWindow = $("#dialog");
});


$("#login").live("pageinit", function(event) {

	initInput();

	$("#loginbtn").on("click", loginUser);
	
	$("#autoLogin").on( 'slidestop', function( event ) {

		$.cookie("autoLogin", $("#autoLogin").val(), {
			expires : 7
		});
	});
});

function loginUser(){
	
	var v = $("#ipname").val();
	if (v.length == 0) {
		showMessage(missIP);
		return;
	}

	v = $("#port").val();
	if (v.length == 0) {
		showMessage(missPort);
		return;
	}

	v = $("#userName").val();
	if (v.length == 0) {
		showMessage(missName);
		return;
	}

	v = $("#password").val();
	if (v.length == 0) {
		showMessage(missPassword);
		return;
	}

	var ht = $("#toggleswitch1").val() == "off" ? "http://" : "https://";
	webSight = ht + $("#ipname").val() + ":" + $("#port").val() + "/";

	var loginData = {};
	$.each(loginIds, function(key, value) {
		$.cookie(value, $("#" + value).val(), {
			expires : 7
		});
		loginData[value] = $("#" + value).val();
	});
	loginData["action"] = "login";

	var callbackfunc = function() {

		accessToken = ajaxBackData.accessToken;
		permissions = ajaxBackData.permissions;
		myMenus = ("" + ajaxBackData.myMenus).split(",");
		me=$.cookie("userName");

		if (myMenus[0] == "jobs") {
			jobPage.state = "";
			$.mobile.changePage("listJob.html", {
				transition : 'slideup',
				reverse : false

			});
		} else {
			activityPage.state = "";
			$.mobile.changePage("listActivity.html", {
				transition : 'slideup',
				reverse : false,
			});
		}
	};

	useAjax(loginData, callbackfunc);
}