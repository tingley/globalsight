$("#listActivity").live("pageshow", function(event) {
	
	if (loadActivity) {
		loadActivity = false;
		activityPage.state = "available";
		initListActivityFooter();
		initActivity();
		initActivityNavButton();
	}

	updateForDetailActivity();
	initActivityUI();
	
	alertContent = $("#messageContent4");
	alertWindow = $("#dialog4");
});

$("#listActivity").live("pageinit", function(event) {

	activitylist = $("#activitylist");

	initActivityImg();

	activityPage.state = "available";
	initActivity();

	initActivityNavBuntton();
	initActivityScroll();
	initActivityEvent();
});

function initActivityUI() {

	var b = $("#listActivity").find(".buttomTools[name='jobs']");
	b.hide();
	for(var i=0;i<myMenus.length;i++)  
	{  
	    if(myMenus[i] == "jobs")  {
	    	b.show();
	    	return;
	    }
	}
	
}

function acceptActivity() {

	if (!hasPermission("perm_activities_accept")) {
		showMessage(noPermissionAcceptTask);
		return;
	}

	var ch = activitylist.find(".listli:visible");
	var temp = [];
	var accepts = [];

	ch.each(function() {
		var bl = $(this).find(".selected").is(":visible");
		if (bl) {
			var value = $(this).find(".taskId").text();
			temp.push(value);
			
			if (hasPermission("projects_manage")) {
				var ascer=$(this).find(".assignees").text().split(",");
				if($.inArray(me, ascer)<0){
					accepts.push($(this).find(".jobId").text());
				}
			}			
		}
	});
	
	if (accepts.length > 0) {
		var msg = "The activities (Job Id:" + accepts + ") " + acceptActivityAssigness;
		
		showMessage(msg);
		return;
	}

	if (temp.length == 0) {
		showMessage(noTaskSelected);
		return;
	}

	var confirmCallBack = function(button) {
		$("#confirmDialog4").popup("close");

		var ajaxData = {};
		ajaxData["taskId"] = temp;
		ajaxData["action"] = "acceptTask";

		var callbackfunc = function() {
			var ch = activitylist.find(".listli:visible");
			ch.each(hideSelectActivity);
		};

		useAjax(ajaxData, callbackfunc);

	};
	confirm4(confirmAcceptActivityHead, confirmAcceptActivityContent, confirmCallBack);

}

function completeActivity() {

	var ch = activitylist.find(".listli:visible");
	var temp = [];
	var accepts = [];

	ch.each(function() {
		var bl = $(this).find(".selected").is(":visible");
		if (bl) {
			var value = $(this).find(".taskId").text();
			temp.push(value);
			
			if (hasPermission("projects_manage")) {
				var ascer=$(this).find(".acceptor").text().split(",");
				if($.inArray(me, ascer)<0){
					accepts.push($(this).find(".jobId").text());
				}
			}	
		}
	});
	
	if (accepts.length > 0) {
		var msg = "The activities (Job Id:" + accepts + ") " + completeActivityAssigness;
		
		showMessage(msg);
		return;
	}

	if (temp.length == 0) {
		showMessage(noTaskSelected);
		return;
	}

	var confirmCallBack = function(button) {
		$("#confirmDialog4").popup("close");

		var ajaxData = {};
		ajaxData["taskId"] = temp;
		ajaxData["action"] = "completeTask";

		var callbackfunc = function() {
			var ch = activitylist.find(".listli:visible");
			ch.each(hideSelectActivity);
		};

		useAjax(ajaxData, callbackfunc);

	};
	confirm4(confirmAcceptActivityHead, confirmAcceptActivityContent, confirmCallBack);

}

function confirm4(head, msg, func) {
	$("#confirmHeader4").text(head);
	$("#confirmMessage4").text(msg);

	$("#okButton4").die();
	$("#okButton4").live("click", func);
	$("#confirmDialog4").popup("open");
}

function hideSelectActivity() {
	var bl = $(this).find(".selected").is(":visible");
	if (bl) {
		$(this).hide('normal', function() {
			$(this).remove();
		});
	}
}

function initListActivityFooter() {
	$("#listActivity").find("#Accept").show();
	$("#listActivity").find("#Complete").hide();
}

function initActivityNavButton() {
	$("#availableNav").addClass("ui-btn-active");
	$("#acceptedNav").removeClass("ui-btn-active");
	$("#finishedNav").removeClass("ui-btn-active");
}

function initActivityImg() {
	var ceckImg = activitylist.find(".ui-block-a");
	ceckImg.each(function() {
		$(this).bind("click", toggleV);
	});
}

function initActivityEvent() {
	activitylist.find(".listli").each(function() {
		$(this).bind("click", checkActivityDetail);
	});
	
	$("#listActivity").find(".buttomTools[name='jobs']").bind("click", function (){
	 $.mobile.changePage("listJob.html", {
					transition: 'slideup',
					reverse: false
				});
	      }	
	);
	
	$("#listActivity").find(".buttomTools[name='logout']").bind("click", logout);
	$("#listActivity").find("#Accept").bind("click", acceptActivity);
	$("#listActivity").find("#Complete").bind("click", completeActivity);
}

var detailActivityLi;

function checkActivityDetail() {
	var ajaxData = {};
	ajaxData["taskId"] = $(this).find(".taskId").text();
	ajaxData["action"] = "detailActivity";

	detailActivityLi = $(this);

	var callbackfunc = function() {
		activityPage.detailActivity = ajaxBackData;

		$.each(listActivityUI, function(key, name) {
			activityPage.detailActivity[name] = detailActivityLi.find("." + name).text();
		});
		
		$.mobile.changePage("detailActivity.html", {
			transition : 'slide',
			reverse : false
		});
	};

	useAjax(ajaxData, callbackfunc);
}

function initActivityNavBuntton() {
	$("#availableNav").bind("click", function() {
		activityPage.state = "available";
		initActivity();
		
		$("#listActivity").find("#Accept").show();
		$("#listActivity").find("#Complete").hide();
	});

	$("#acceptedNav").bind("click", function() {
		activityPage.state = "accepted";
		initActivity();
		
		$("#listActivity").find("#Accept").hide();
		$("#listActivity").find("#Complete").show();
	});

	$("#finishedNav").bind("click", function() {
		activityPage.state = "finished";
		initActivity();
		
		$("#listActivity").find("#Accept").hide();
		$("#listActivity").find("#Complete").hide();
	});
}

function activityPullDownAction() {
	var taskId = activitylist.find(".taskId").eq(1).text();
	var ajaxData = {};
	ajaxData["taskId"] = taskId;
	ajaxData["condition"] = "gt";
	ajaxData["status"] = activityPage.state;
	ajaxData["action"] = "getActivities";

	var callbackfunc = function() {
		var node1 = activitylist.children().eq(0).clone(true);
		var firstNode = activitylist.children().eq(0);
		for (var i = ajaxBackData.length - 1; i >= 0; i--)
		{
		    var newNode=node1.clone(true);
	        newNode.show();
	        $.each(listActivityUI,function(key,name){
		       var nodechildren =newNode.find("."+name).eq(0);
		       nodechildren.text(ajaxBackData[i][name]);						
	        });
	
	        newNode.insertAfter(firstNode);
		}	

		$(".selected:visible").each(function() {
			$(this).trigger(clickEvent);
		});

		activitylist.listview("refresh");
		activityScroll.refresh();
	};

	useAjax(ajaxData, callbackfunc);
	activityScroll.refresh();
}

function activityPullUpAction() {

	var hLi = activitylist.find("li:hidden");
	if (hLi.length > 1) {
		for ( var i = 1; i < hLi.length && i < pageNum + 1; i++) {
			$(hLi[i]).show();
		}

		activitylist.listview("refresh");
		activityScroll.refresh();

		return;
	}

	$.mobile.loadingMessageTextVisible = true;
	$.mobile.showPageLoadingMsg('a', "Please wait...");

	var tId = activitylist.find(".taskId").last().text();
	var ajaxData = {};
	ajaxData["taskId"] = tId;
	ajaxData["condition"] = "lt";
	;
	ajaxData["status"] = activityPage.state;
	ajaxData["action"] = "getActivities";

	var callbackfunc = function() {
		var node1 = activitylist.children().eq(0).clone(true);
		for ( var i = 0; i < ajaxBackData.length; i++) {
			var newNode = node1.clone(true);
			newNode.show();
			$.each(listActivityUI, function(key, name) {
				var nodechildren = newNode.find("." + name).eq(0);
				nodechildren.text(msg[i][name]);
			});

			activitylist.append(newNode);
		}

		$(".selected:visible").each(function() {
			$(this).trigger(clickEvent);
		});

		activitylist.listview("refresh");
		activityScroll.refresh();
	};

	useAjax(ajaxData, callbackfunc);
}

function updateForDetailActivity(){
	if (detailActivityId){
		var ajaxData = {};
		ajaxData["taskId"] = detailActivityId;
		ajaxData["action"] = "getTaskState";

		var callbackfunc = function() {
			var statues = ajaxBackData.taskStatus;
			if (statues != activityPage.state) {
				var ch = activitylist.find(".listli:visible");
				for (var i = 0; i < ch.length; i++){
					var c = $(ch[i]);
					var taskId = c.find(".taskId").text();
					if (taskId == detailActivityId) {
						c.hide('normal', function() {
							c.remove();
						});
						break;
					}
				}		
			}
			
			detailActivityId = false;
		};

		useAjax(ajaxData, callbackfunc);
	}
}

function initActivityScroll() {
	activityPullDownEl = $('#pullDown')[0];
	activityPullDownOffset = activityPullDownEl.offsetHeight;
	activityPullUpEl = $('#pullUp')[0];
	activitypullUpOffset = activityPullUpEl.offsetHeight;

	activityScroll = new iScroll(
			'wrapperActivity',
			{
				useTransition : true,
				topOffset : activityPullDownOffset,
				onRefresh : function() {
					if (activityPullDownEl.className.match('loading')) {
						activityPullDownEl.className = '';
						activityPullDownEl.querySelector('.pullDownLabel').innerHTML = 'Pull down to refresh...';
					} else if (activityPullUpEl.className.match('loading')) {
						activityPullUpEl.className = '';
						activityPullUpEl.querySelector('.pullUpLabel').innerHTML = 'Pull up to load more...';
					}
				},
				onScrollMove : function() {
					if (this.y > 5 && !activityPullDownEl.className.match('flip')) {
						activityPullDownEl.className = 'flip';
						activityPullDownEl.querySelector('.pullDownLabel').innerHTML = 'Release to refresh...';
						this.minScrollY = 0;
					} else if (this.y < 5 && activityPullDownEl.className.match('flip')) {
						activityPullDownEl.className = '';
						activityPullDownEl.querySelector('.pullDownLabel').innerHTML = 'Pull down to refresh...';
						this.minScrollY = -activityPullDownOffset;
					} else if (this.y < (this.maxScrollY - 5)
							&& !activityPullUpEl.className.match('flip')) {
						activityPullUpEl.className = 'flip';
						activityPullUpEl.querySelector('.pullUpLabel').innerHTML = 'Release to refresh...';
						this.maxScrollY = this.maxScrollY;
					} else if (this.y > (this.maxScrollY + 5)
							&& activityPullUpEl.className.match('flip')) {
						activityPullUpEl.className = '';
						activityPullUpEl.querySelector('.pullUpLabel').innerHTML = 'Pull up to load more...';
						this.maxScrollY = activitypullUpOffset;
					}
				},
				onScrollEnd : function() {
					if (activityPullDownEl.className.match('flip')) {
						activityPullDownEl.className = 'loading';
						activityPullDownEl.querySelector('.pullDownLabel').innerHTML = 'Loading...';
						activityPullDownAction(); // Execute custom function (ajax
											// call?)
					} else if (activityPullUpEl.className.match('flip')) {
						activityPullUpEl.className = 'loading';
						activityPullUpEl.querySelector('.pullUpLabel').innerHTML = 'Loading...';
						activityPullUpAction(); // Execute custom function (ajax call?)
					}
				}
			});
}

function initActivity() {
	activitylist.find("li:gt(0)").remove();
	
	var ajaxData = {};
	ajaxData["taskId"] = "";
	ajaxData["condition"] = "";
	ajaxData["status"] = activityPage.state;
	ajaxData["action"] = "getActivities";

	var callbackfunc = function() {
		activitylist.listview("refresh");
		activityScroll.refresh();

		var node1 = activitylist.children().eq(0).clone(true);
		for ( var i = 0; i < ajaxBackData.length; i++) {
			var newNode = node1.clone(true);

			if (i < pageNum) {
				newNode.show();
			}

			$.each(listActivityUI, function(key, name) {
				var nodechildren = newNode.find("." + name).eq(0);
				nodechildren.text(ajaxBackData[i][name]);
			});
			
			if (hasPermission("projects_manage")) {
				newNode.find(".assigneesLab").show();
			}

			activitylist.append(newNode);
		}

		$(".selected:visible").each(function() {
			$(this).trigger(clickEvent);
		});

		activitylist.listview("refresh");
		activityScroll.refresh();
	};

	useAjax(ajaxData, callbackfunc);
}