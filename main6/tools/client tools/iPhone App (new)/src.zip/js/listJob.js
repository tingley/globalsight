$("#listJob").live("pageshow", function(event) {

	if (loadJob) {
		loadJob = false;
		jobPage.state = "ready";
		initListJobFooter();
		initJob();
		initJobNavButton();
	}

	updateForDetailJob();
	initJobUI();
	
	alertContent = $("#messageContent2");
	alertWindow = $("#dialog2");
});


$("#listJob").live("pageinit", function(event) {
	
	joblist = $("#thelist");
	var ceckImg = joblist.find(".ui-block-a");
	
	ceckImg.each(function() {
		$(this).bind("click", toggleV);
	});

	jobPage.state = "ready";
	initListJobFooter();
	initJob();
	initListJobNavBuntton();
	initListJobScroll();
	initListJobEvent();
});

function initJobUI() {

	var b = $("#listJob").find(".buttomTools[name='activities']");
	b.hide();
	for(var i=0;i<myMenus.length;i++)  
	{  
	    if(myMenus[i] == "activities")  {
	    	b.show();
	    	return;
	    }
	}
}

function updateForDetailJob(){
	if (detailJobId){
		var ajaxData = {};
		ajaxData["jobId"] = detailJobId;
		ajaxData["action"] = "getJobState";

		var callbackfunc = function() {
			var statues = ajaxBackData.jobStatus;
			if (statues != jobPage.state) {
				var ch = joblist.find(".listli:visible");
				for (var i = 0; i < ch.length; i++){
					var c = $(ch[i]);
					var jobId = c.find(".jobId").text();
					if (jobId == detailJobId) {
						c.hide('normal', function() {
							c.remove();
						});
						break;
					}
				}		
			}
			
			detailJobId = false;
		};

		useAjax(ajaxData, callbackfunc);
	}
}

function initJobNavButton() {
	$("#ready").addClass("ui-btn-active");
	$("#dispatched").removeClass("ui-btn-active");
	$("#exported").removeClass("ui-btn-active");
	$("#pending").removeClass("ui-btn-active");
}

function initListJobEvent() {
	joblist.find(".listli").each(function() {
		$(this).bind("click", checkJobDetail);
	});

	$("#listJob").find(".buttomTools[name='jobs']").bind("click", function() {
		$.mobile.changePage("listJob.html", {
			transition : 'slideup',
			reverse : false
		});
	});

	$("#listJob").find(".buttomTools[name='activities']").bind("click",
			function() {
				$.mobile.changePage("listActivity.html", {
					transition : 'slideup',
					reverse : false
				});
			});

	$("#listJob").find(".buttomTools[name='logout']").bind("click", logout);
	$("#listJob").find("#Discard").bind("click", discardJob);
	$("#listJob").find("#Dispatch").bind("click", dispatchJob);
}

function initListJobFooter() {
	$("#listJob").find("#Discard").show();
	$("#listJob").find("#Dispatch").show();
}

function confirm2(head, msg, func) {
	$("#confirmHeader2").text(head);
	$("#confirmMessage2").text(msg);

	$("#okButton2").die();
	$("#okButton2").live("click", func);
	$("#confirmDialog2").popup("open");
}

var detailJobLi;

function checkJobDetail() {
	var ajaxData = {};
	ajaxData["jobId"] = $(this).find(".jobId").text();
	ajaxData["action"] = "detailJob";

	detailJobLi = $(this);

	var callbackfunc = function() {
		jobPage.detailJob = ajaxBackData;
		jobPage.detailJob.jobId = detailJobLi.find(".jobId").text();
		jobPage.detailJob.jobName = detailJobLi.find(".jobName").text();
		jobPage.detailJob.dateCreated = detailJobLi.find(".dateCreated").text();
		jobPage.detailJob.jobWC = detailJobLi.find(".jobWC").text();

		$.mobile.changePage("detailJob.html", {
			transition : 'slide',
			reverse : false
		});
	};

	useAjax(ajaxData, callbackfunc);
}

function dispatchJob() {

	if (!hasPermission("perm_jobs_dispatch")) {
		showMessage(noPermissionDispatch);
		return;
	}

	var ch = joblist.find(".listli:visible");
	var temp = [];

	ch.each(function() {
		var bl = $(this).find(".selected").is(":visible");
		if (bl) {
			var value = $(this).find(".jobId").text();
			temp.push(value);
		}
	});

	if (temp.length == 0) {
		showMessage(noJobSelected);
		return;
	}

	var confirmCallBack = function(button) {
		$("#confirmDialog2").popup("close");

		var ajaxData = {};
		ajaxData["jobId"] = temp;
		ajaxData["action"] = "dispatchJob";

		var callbackfunc = function() {
		var ch = joblist.find(".listli:visible");
			ch.each(hideSelectJob);
		};

		useAjax(ajaxData, callbackfunc);

	};
	confirm2(confirmDispatchHead, confirmDispatchContent, confirmCallBack);
}

function discardJob() {

	if (!hasPermission("perm_jobs_discard")) {
		showMessage(noPermissionDiscard);
		return;
	}

	var ch = joblist.find(".listli:visible");
	var temp = [];

	ch.each(function() {
		var bl = $(this).find(".selected").is(":visible");
		if (bl) {
			var value = $(this).find(".jobId").text();
			temp.push(value);
		}
	});

	if (temp.length == 0) {
		showMessage(noJobSelected);
		return;
	}

	var confirmCallBack = function(button) {
		$("#confirmDialog2").popup("close");

		var ajaxData = {};
		ajaxData["jobId"] = temp;
		ajaxData["action"] = "discardJob";

		var callbackfunc = function() {
			var ch = joblist.find(".listli:visible");
			ch.each(hideSelectJob);
		};

		useAjax(ajaxData, callbackfunc);

	};
	confirm2(confirmDiscardHead, confirmDiscardContent, confirmCallBack);

}

function hideSelectJob() {
	var bl = $(this).find(".selected").is(":visible");
	if (bl) {
		$(this).hide('normal', function() {
			$(this).remove();
		});
	}
}

function initListJobNavBuntton() {
	$("#ready").bind("click", function() {
		$("#listJob").find("#Discard").show();
		$("#listJob").find("#Dispatch").show();

		jobPage.state = "ready";
		initJob();
	});

	$("#dispatched").bind("click", function() {
		$("#listJob").find("#Discard").show();
		$("#listJob").find("#Dispatch").hide();

		jobPage.state = "dispatched";
		initJob();
	});

	$("#exported").bind("click", function() {
		$("#listJob").find("#Discard").hide();
		$("#listJob").find("#Dispatch").hide();

		jobPage.state = "exported";
		initJob();
	});

	$("#pending").bind("click", function() {
		$("#listJob").find("#Discard").show();
		$("#listJob").find("#Dispatch").hide();

		jobPage.state = "pending";
		initJob();
	});
}

function pullDownAction() {

	var jId = joblist.find(".jobId").eq(1).text();
	var ajaxData = {};
	ajaxData["jobId"] = jId;
	ajaxData["jobCondition"] = "gt";
	ajaxData["status"] = jobPage.state;
	ajaxData["action"] = "getJobs";

	var callbackfunc = function() {
		var node1 = joblist.children().eq(0).clone(true);
		var firstNode = joblist.children().eq(0);
		for (var i = ajaxBackData.length - 1; i >= 0; i--)
		{
		    var newNode=node1.clone(true);
	        newNode.show();
	        $.each(listJobUI,function(key,name){
		       var nodechildren =newNode.find("."+name).eq(0);
		       nodechildren.text(ajaxBackData[i][name]);						
	        });
	
	        newNode.insertAfter(firstNode);
		}	

		$(".selected:visible").each(function() {
			$(this).trigger(clickEvent);
		});

		joblist.listview("refresh");
		jobScroll.refresh();
	};

	useAjax(ajaxData, callbackfunc);
}

function pullUpAction() {
	var hLi = joblist.find("li:hidden");
	if (hLi.length > 1) {
		for ( var i = 1; i < hLi.length && i < pageNum + 1; i++) {
			$(hLi[i]).show();
		}

		joblist.listview("refresh");
		jobScroll.refresh();

		return;
	}

	$.mobile.loadingMessageTextVisible = true;
	$.mobile.showPageLoadingMsg('a', "Please wait...");
	var jId = joblist.find(".jobId").last().text();

	var ajaxData = {};
	ajaxData["jobId"] = jId;
	ajaxData["jobCondition"] = "lt";
	ajaxData["status"] = jobPage.state;
	ajaxData["action"] = "getJobs";

	var callbackfunc = function() {
		var node1 = joblist.children().eq(0).clone(true);
		for ( var i = 0; i < ajaxBackData.length; i++) {
			var newNode = node1.clone(true);
			newNode.show();
			$.each(listJobUI, function(key, name) {
				var nodechildren = newNode.find("." + name).eq(0);
				nodechildren.text(ajaxBackData[i][name]);
			});

			joblist.append(newNode);
		}

		$(".selected:visible").each(function() {
			$(this).trigger(clickEvent);
		});

		$.mobile.hidePageLoadingMsg();
		joblist.listview("refresh");
		jobScroll.refresh();
	};

	useAjax(ajaxData, callbackfunc);
}

function initListJobScroll() {
	jobPullDownEl = $('#pullDown')[0];
	jobPullDownOffset = jobPullDownEl.offsetHeight;
	jobPullUpEl = $('#pullUp')[0];
	jobPullUpOffset = jobPullUpEl.offsetHeight;

	jobScroll = new iScroll(
			'wrapperJob',
			{
				useTransition : true,
				topOffset : jobPullDownOffset,
				onRefresh : function() {
					if (jobPullDownEl.className.match('loading')) {
						jobPullDownEl.className = '';
						jobPullDownEl.querySelector('.pullDownLabel').innerHTML = 'Pull down to refresh...';
					} else if (jobPullUpEl.className.match('loading')) {
						jobPullUpEl.className = '';
						jobPullUpEl.querySelector('.pullUpLabel').innerHTML = 'Pull up to load more...';
					}
				},
				onScrollMove : function() {
					if (this.y > 5 && !jobPullDownEl.className.match('flip')) {
						jobPullDownEl.className = 'flip';
						jobPullDownEl.querySelector('.pullDownLabel').innerHTML = 'Release to refresh...';
						this.minScrollY = 0;
					} else if (this.y < 5
							&& jobPullDownEl.className.match('flip')) {
						jobPullDownEl.className = '';
						jobPullDownEl.querySelector('.pullDownLabel').innerHTML = 'Pull down to refresh...';
						this.minScrollY = -jobPullDownOffset;
					} else if (this.y < (this.maxScrollY - 5)
							&& !jobPullUpEl.className.match('flip')) {
						jobPullUpEl.className = 'flip';
						jobPullUpEl.querySelector('.pullUpLabel').innerHTML = 'Release to refresh...';
						// this.maxScrollY = this.maxScrollY;
					} else if (this.y > (this.maxScrollY + 5)
							&& jobPullUpEl.className.match('flip')) {
						jobPullUpEl.className = '';
						jobPullUpEl.querySelector('.pullUpLabel').innerHTML = 'Pull up to load more...';
						this.maxScrollY = jobPullUpOffset;
					}
				},
				onScrollEnd : function() {
					if (jobPullDownEl.className.match('flip')) {
						jobPullDownEl.className = 'loading';
						jobPullDownEl.querySelector('.pullDownLabel').innerHTML = 'Loading...';
						pullDownAction(); // Execute custom function (ajax
						// call?)
					} else if (jobPullUpEl.className.match('flip')) {
						jobPullUpEl.className = 'loading';
						jobPullUpEl.querySelector('.pullUpLabel').innerHTML = 'Loading...';
						pullUpAction(); // Execute custom function (ajax call?)
					}
				}
			});
}

var listJobUI = [ "jobId", "jobName", "dateCreated", "jobWC" ];

function initJob() {
	
	joblist.find("li:gt(0)").remove();
	
	var ajaxData = {};
	ajaxData["jobId"] = "";
	ajaxData["jobCondition"] = "";
	ajaxData["status"] = jobPage.state;
	ajaxData["action"] = "getJobs";

	var callbackfunc = function() {
		
		joblist.listview("refresh");
		jobScroll.refresh();

		var node1 = joblist.children().eq(0).clone(true);
		for ( var i = 0; i < ajaxBackData.length; i++) {
			var newNode = node1.clone(true);

			if (i < pageNum) {
				newNode.show();
			}

			$.each(listJobUI, function(key, name) {
				var nodechildren = newNode.find("." + name).eq(0);
				nodechildren.text(ajaxBackData[i][name]);
			});

			joblist.append(newNode);
		}

		$(".selected:visible").each(function() {
			$(this).trigger(clickEvent);
		});

		joblist.listview("refresh");
		jobScroll.refresh();
	};

	useAjax(ajaxData, callbackfunc);
}