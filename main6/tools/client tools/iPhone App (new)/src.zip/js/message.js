//validate
var missIP = "Please input a HostName/IP to log in";
var missPort = "Please input a port to log in";
var missName = "Please input a user name to log in";
var missPassword = "Please input a password to log in";

// dialog
var noJobSelected = "Please select at least one job.";
var noTaskSelected = "Please select at least one activity.";
var noWorkflowSelected = "Please select at least one workflow.";
var confirmDispatchHead = "Dispatch Job";
var confirmDiscardHead = "Discard Job";
var confirmAcceptActivityHead = "Accept Activity";
var confirmDispatchWorkflowHead = "Dispatch Workflow";
var confirmDispatchContent = "Are you sure to dispatch selected job(s)?";
var noPermissionDispatch = "You do not have the permission to dispatch job. Please contact the administrator.";
var noPermissionDiscard = "You do not have the permission to discard job. Please contact the administrator.";
var noPermissionDispatchWorkflow = "You do not have the permission to dispatch workflow. Please contact the administrator.";
var noPermissionDiscardWorkflow = "You do not have the permission to discard workflow. Please contact the administrator.";
var noPermissionAcceptTask = "You do not have the permission to accept activity. Please contact the administrator.";
var confirmDiscardContent = "Are you sure to discard selected job(s)?";
var confirmAcceptActivityContent = "Are you sure to accept selected activity(s)?";
var confirmDispatchWorkflowContent = "Are you sure to dispatch selected workflow(s)?";
var dispatchWorkflowStateWrong = "Only workflows in 'Ready' state can be dispatched.";
var discardWorkflowStateWrong = "Only workflows in 'Ready' and 'Dispatched' states can be discarded.";
var acceptActivityAssigness = "can not be accepted since you are not the assignee";
var completeActivityAssigness = "can not be completed since you are not the assignee";
var acceptDetailActivityAssigness = "This activity can not be accepted since you are not the assignee.";
var completeDetailActivityAssigness = "This activity can not be completed since you are not the assignee.";