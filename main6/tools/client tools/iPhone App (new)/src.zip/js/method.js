function toggleV(event) {
	$(this).find("img").toggle();
	event.stopPropagation();
}

function hasPermission(p) {
	return permissions.indexOf(p) > -1;
}

function logout() {

	loadJob = true;
	loadActivity = true;

	$.mobile.changePage("index.html", {
		transition : 'slideup',
		reverse : false
	});
}

function showMessage(msg) {
	message = msg;
	alertContent.text(msg);
	alertWindow.popup("open");
}

function confirm2(head, msg, func) {
	$("#confirmHeader2").text(head);
	$("#confirmMessage2").text(msg);

	$("#okButton2").die();
	$("#okButton2").live("click", func);
	$("#confirmDialog2").popup("open");
}

function useAjax(ajaxData, callbackfunc) {
	$.mobile.loadingMessageTextVisible = true;
	$.mobile.showPageLoadingMsg();

	ajaxData["accessToken"] = accessToken;

	$
			.ajax({
				type : "get",
				dataType : "json",
				url : webSight + MobileService,
				cache : false,
				timeout : 60000,
				data : ajaxData,
				crossDomain : true,
				success : function(msg) {
					
					if (msg == null) {
						showMessage("Server is no response.");
						return;
					}

					if (msg.success == 'no') {
						var info=msg.GSErrorMsg.split("::")[1];
						showMessage(info);
						return;
					}

					ajaxBackData = msg;
					if (callbackfunc && typeof (callbackfunc) === 'function') {
						// may we need change vieews first
						callbackfunc();
					}
				},

				beforeSend : function() {
				},
				error : function(jqXHR, textStatus, errorThrown) {
					showMessage("Can't load data. please check your web connection...");
				},
				complete : function() {
					$.mobile.hidePageLoadingMsg();
				}
			});
}
